import express from "express";
import { createConnection } from "mysql";
import cors from 'cors';

const app = express();
app.use(cors())
app.use(express.json());

const conn = createConnection({
  host: "localhost",
  user: "root",
  password: "password",
  database: "weather_app",
});
conn.connect((error) => {
  if (error) {
    console.log(error);
  } else {
    console.log("Database connected !");
  }
});

app.post("/survey", (request, response) => {
  console.log(request.body);
  var insertQry = `INSERT INTO surveyform VALUES(
        '${request.body.name}',
        '${request.body.lastname}',
        ${request.body.phone_No},'${request.body.email}','${request.body.city}',${request.body.zip})`;
  conn.query(insertQry, (error, result) => {
    if (error) {
      response.status(500).send({ message: "Error in inserting value" });
    } else {
      response
        .status(200)
        .send({ message: "Survey Form Submitted Sucessfully!!" });
    }
  });
});

app.get("/survey", (request, response) => {
  var selectQry = "SELECT * FROM surveyform";
  conn.query(selectQry, (error, result) => {
    if (error) {
      response.status(500).send({ message: "Error in fetching students" });
    } else {
      response.status(200).send(result);
    }
  });
});
app.listen(9800, () => {
  console.log("listening on 9800");
});
