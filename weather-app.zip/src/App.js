
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Weather } from "./components/Weather";
import { NavigationBar } from "./components/NavigationBar";
import 'bootstrap/dist/css/bootstrap.min.css';
import About from "../src/components/About"
import { Contact } from "./components/Contact";
import Login from "./components/login";
import Sign from "./components/signup";


function App() {
  return (
      <>
        <BrowserRouter>
          {<NavigationBar></NavigationBar>}
          <Routes>
            <Route path="/" element={<Weather></Weather>}></Route>
            <Route path="/about" element={<About></About>}></Route>
            <Route path="/contact" element={<Contact></Contact>}></Route>
            <Route path="/login" element={<Login></Login>}></Route>
            <Route path="/signup" element={<Sign></Sign>}></Route>
            
          </Routes>
        </BrowserRouter>
      </>    
  );
}
export default App;
