import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { LinkContainer } from 'react-router-bootstrap';

export function NavigationBar() {
  return (
    <>
    <Navbar bg="dark" variant="dark">
          <Navbar.Brand href="#home">Welcome to Weather-App</Navbar.Brand>
          <Nav className="me-auto">
            <Nav.Link href="/">Home</Nav.Link>
            <Nav.Link href="/about">About Us</Nav.Link>
            <Nav.Link href="/contact">Contact Us</Nav.Link>
          </Nav>
          <Nav className='me-auto'>
          <Nav.Link href="/login">login</Nav.Link>
            <Nav.Link href="/signup">Signup</Nav.Link>  
          </Nav>
      </Navbar>
    </>
  );
}
