import React, { useState } from 'react';
import { Button, Card, Form, InputGroup } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

// const users = [
//   {
//     username: 'admin',
//     password: '123',
//   },
//   {
//     username: 'user',
//     password: '123',
//   },
// ];

const Login = () => {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [validated, setValidated] = useState(false);
  // const [invalidUser, setInvalidUser] = useState(false);
  // const [invalidPassword, setInvalidPassword] = useState(false);

  const handleSubmit = (event) => {
    console.log('handleSubmit');
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    } else {
      navigate('/home');
    }
    setValidated(true);
  };
  return (
    <div
      className="container-fluid"
      style={{
        height: '100vh',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundSize: 'cover',
        backgroundRepeat: 'no-repeat',
        backgroundImage: "../src/asset/main_bg.jpg",
        
      }}
    >
      <Card
        style={{
          width: '22rem',
          backgroundColor: ' rgba(0,0,0, 0.7)',
          color: 'white',
        }}
      >
        <Card.Body>
          <Card.Title className="text-center">Login</Card.Title>
          <div
            style={{
              textAlign: 'center',
            }}
          >
            <Form noValidate validated={validated} onSubmit={handleSubmit}>
              <Form.Group className="mb-3" controlId="formBasicEmail">
                <Form.Label>Username</Form.Label>
                <InputGroup hasValidation>
                  <Form.Control
                    type="email"
                    placeholder="Username"
                    aria-describedby="inputGroupPrepend"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                  />
                  <Form.Control.Feedback type="invalid">
                    Please enter a username.
                  </Form.Control.Feedback>
                </InputGroup>
              </Form.Group>

              <Form.Group className="mb-3" controlId="formBasicPassword">
                <Form.Label>Password</Form.Label>
                <InputGroup hasValidation>
                  <Form.Control
                    type="password"
                    placeholder="Password"
                    aria-describedby="inputGroupPrepend"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    minLength={5}
                  />
                  <Form.Control.Feedback type="invalid">
                    Please enter a password.
                  </Form.Control.Feedback>
                </InputGroup>
              </Form.Group>

              <Button variant="primary" type="submit" style={{ width: '100%' }}>
                Sign In
              </Button>
            </Form>
          </div>
          <Card.Text className="pt-2">
            Don't have an account?{' '}
            <Button
              variant="primary"
              type="submit"
              style={{ width: '100%' }}
              onClick={() => navigate('/register')}
            >
              Sign Up
            </Button>
            {/* <a
              href="/register"
              style={{
                textDecoration: 'none',
                fontWeight: 'bold',
                color: 'red',
              }}
            >
              Register here
            </a> */}
          </Card.Text>
        </Card.Body>
      </Card>
    </div>
  );
};

export default Login;