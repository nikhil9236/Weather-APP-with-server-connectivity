import React from "react";
import"../asset/style.css";

export default  function About(){
    return(
        <div>
        <section id="ABOUT">
          <div className="about-1">
            <h1>ABOUT US</h1>
            <p>
              Weather forecasting is the application of science and technology to
              predict the conditions of the atmosphere for a given location and
              time. People have attempted to predict the weather informally for
              millennia and formally since the 19th century. Weather forecasts are
              made by collecting quantitative data about the current state of the
              atmosphere, land, and ocean and using meteorology to project how the
              atmosphere will change at a given place.
            </p>
          </div>
          <div id="about-2">
            <div className="content-box-lg">
              <div className="container">
                <div className="row">
                  <div className="col-md-4">
                    <div className="about-item text-center">
                      <i className="fa fa-book" />
                      <h3>MISSION</h3>
                      <hr />
                      <p>
                        Weather warnings are important forecasts because they are
                        used to protect life and property. Forecasts based on
                        temperature and precipitation are important to agriculture,
                        and therefore to traders within commodity markets.
                        Temperature forecasts are used by utility companies to
                        estimate demand over coming days.
                      </p>
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="about-item text-center">
                      <i className="fa fa-globe" />
                      <h3>VISSION</h3>
                      <hr />
                      <p>
                        Our vission has always been to empower data consumers and
                        analysts to make better decisions based on high-quality,
                        easy-to-access data
                      </p>
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="about-item text-center">
                      <i className="fa fa-pencil" />
                      <h3>FOCUS ON IMPACT</h3>
                      <hr />
                      <p>
                        Weather forecasts and warnings focus on the impact to people
                        and businesses, so they can make the best weather-impacted
                        decisions. A storm producing 2-3 inches of snow may prove
                        insignificant in one geography and bring another to a
                        complete standstill.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/*our footer */}
        <footer className="text-center">
          <p>
            “The best weather prediction for the present moment is to look out of
            the window!”
          </p>
          <ul>
            <li>
              <a href="file:///D:/WeatherForecast/home%20page/index.html">Home</a>
            </li>
          </ul>
        </footer>
      </div>

    );

}