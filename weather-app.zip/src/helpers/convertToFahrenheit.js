export default function convertToFahrenheit(celsius) {
  return (celsius * 9) / 5 + 32;
}
